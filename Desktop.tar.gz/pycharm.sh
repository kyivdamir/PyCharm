#! /usr/bin/bash
./start-ubuntu20.sh<<echo./start-pycharm.sh
./start-pycharm.sh